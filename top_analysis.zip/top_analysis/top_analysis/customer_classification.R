# Load packages
library(tidyverse) # manipulation
library(janitor)  #cleaning data
library(patchwork)  #For joining plots
library(cluster)  # for kmeans
library(factoextra) #for visualization of kmeans
library(scales)  #for decorating graph and table scales
library(lubridate)

#Time Column
credit_data <- ke_ng %>% 
  mutate(Delivery.Time = lubridate::as_date(Delivery.Time)) %>% 
  filter(!is.na(Delivery.Time)) 
  

#Recency-Frequency-Monetary Values Data
data <- credit_data %>% group_by(customer_id) %>% 
  summarise('Recency' = as.numeric(max(Delivery.Time) - as.Date('2022-01-03')),
            'Frequency' = n(),
            'TransactionAmount' = sum(Total.Price))

Recency_plot <- ggplot(data, aes(Recency)) +
  geom_histogram(fill = "grey") +
  labs(x = " ",
       y = " ",
       title = "Recency")

Frequency_plot <- ggplot(data %>% filter(Frequency<9994), aes(Frequency)) +
  geom_histogram(fill = "orange") +
  labs(x = " ",
       y = " ",
       title = "Frequency")
Amount_plot <- ggplot(data %>% filter(TransactionAmount< 1000000) , aes(TransactionAmount)) +
  geom_histogram(fill = "midnightblue") +
  labs(x = " ",
       y = " ",
       title = "Transaction amount")
Recency_plot/Frequency_plot/Amount_plot
patchwork1 <- Recency_plot/Frequency_plot/Amount_plot
patchwork1 + plot_annotation(
  title = 'Histograms of features',
  caption = 'Our features are right skewed:\n
  Solomon'
)


#logarithmic Data
new_data = data
row.names(new_data) = new_data$customerId
new_data$customer_id = NULL
new_data$Frequency = log(new_data$Frequency + 1)
new_data$TransactionAmount = log(new_data$TransactionAmount + 1)
log_frequency_plot <- ggplot(data, aes(log(Frequency + 1))) +
  geom_histogram(fill = "grey") +
  labs(x = " ",
       y = " ",
       title = "Frequency")
recency_plot <- ggplot(data, aes(Recency)) +
  geom_histogram(fill = "orange") +
  labs(x = " ",
       y = " ",
       title = "Recency")
log_amount_plot <- ggplot(data, aes(log(TransactionAmount + 1))) +
  geom_histogram(fill = "midnightblue") +
  labs(x = " ",
       y =" ",
       title =  "Transaction amount")
patchwork <- log_frequency_plot/recency_plot/log_amount_plot
patchwork + plot_annotation(
  title = 'Histograms of transformed features',
  caption = 'Disclaimer: Transformation was achieved by logarithm \n plus adding 1'
)

set.seed(123)
# needs factoextra package
fviz_nbclust(new_data, kmeans, method = "wss")+ 
  geom_vline(xintercept = 4, lty =2, col = 'red') +
  theme_minimal() +
  plot_annotation(
    caption = 'Scree plot\n Choosing the number of clusters'
  )

#Build K-Means Model and Assign The Results into segment
data$segment = kmeans(new_data,
                      centers = 4, 
                      nstart = 50)$cluster

#Create Segment Summary
segment_summary_table <- data %>% 
  group_by(segment) %>% 
  summarise('Recency' = mean(Recency),
            'Frequency' = mean(Frequency),
            'TransactionAmount' = mean(TransactionAmount),
            'member' = n()) %>% 
  mutate(TransactionAmount = comma(TransactionAmount),
         member = comma(member)) 

segment_summary_table


