library(tidyverse)
# change customer Id to similar name -- for easy merge
ke_customers <- read_csv("Kenya Customers.csv") %>% 
  rename(customer_id = "Customer ID") %>% 
   select(-`Upload restuarant location`)

ke_orders <- read.csv("Kenya Orders.csv") %>% rename(customer_id = "Customer.ID")

ke_Deliveries <- read_csv("Kenya Deliveries.csv") %>%  
  select(-"...35", -"...36")

ng_customers <- read_csv("Nigeria Customers.csv")%>% 
  rename(customer_id = "Customer ID")
ng_Deliveries <- read_csv("Nigeria Deliveries.csv") %>% 
  mutate(Agent_Name  = "NA")
ng_orders <- read.csv("Nigeria Orders.csv")%>% 
  rename(customer_id = "Customer.ID") %>% 
  mutate("Debt.Amount" = "NA")

# merging orders to customers -- kenya
merged_ke <- ke_orders %>% 
  group_by(customer_id) %>% 
  left_join(ke_customers) %>% 
  ungroup()  

# merging orders to customers -- Nigeria
merged_ng <- ng_orders %>% 
  group_by(customer_id) %>% 
  left_join(ng_customers) %>% 
  ungroup()  

# Remove "YR-" and ",0" -- kenya
new_ke_deliveries <- ke_Deliveries %>% 
  mutate(Order_ID = str_remove(Order_ID, "YR-"),
         Order_ID =str_remove(Order_ID, ",0"), 
         Order_ID = as.integer(Order_ID)) %>% 
  rename(Order.ID = Order_ID) %>% 
  # filter out - since there is no explaination/matching order
  filter(Order.ID != "-") %>% 
  group_by(Order.ID)

# Remove "YR-" and ",0" -- Nigeria
new_ng_deliveries <- ng_Deliveries %>% 
  mutate(Order_ID = str_remove(Order_ID, "YR-"),
         Order_ID =str_remove(Order_ID, ",0"), 
         Order_ID = as.integer(Order_ID)) %>% 
  rename(Order.ID = Order_ID) %>% 
  # filter out - since there is no explaination/matching order
  filter(Order.ID != "-") %>% 
  group_by(Order.ID)

# join merged_ke with deliveries -- Kenya
merged_delivery_ke <- new_ke_deliveries %>% 
  group_by(Order.ID) %>% 
  left_join(merged_ke, by = c("Order.ID"="Order.ID")) %>% 
  ungroup() %>% 
  mutate(Rating  = as.double(Rating),
         Latitude = as.double(Latitude),
         Task_Details_QTY = as.double(Task_Details_QTY),
         Cost.Price = as.double(Cost.Price),
         Total.Cost.Price = as.double(Total.Cost.Price))

# join merged_ng with deliveries -- Nigeria
merged_delivery_ng <- new_ng_deliveries %>% 
  group_by(Order.ID) %>% 
  left_join(merged_ng, by = c("Order.ID"="Order.ID")) %>% 
  ungroup() 


# merge Ke and Ng
ke_ng <- merged_delivery_ke %>% 
  bind_rows(merged_delivery_ng)

write_csv(ke_ng, "Merged_data.csv")

# Data Cleaning -- already done.



